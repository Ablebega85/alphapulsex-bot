#!/usr/bin/env python3

# AlphaPulseX AI Bot - OKX Version with Degen + Smart Signals (Groq + Telegram)

import time
import json
import requests
import threading
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
import os

# === CONFIGURATION ===

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
AI_CONFIDENCE_THRESHOLD = 90.0

HEADERS = {"Authorization": f"Bearer {GROQ_API_KEY}"}

# === TELEGRAM ===

def send_telegram(text, reply_to=None):
    data = {"chat_id": CHAT_ID, "text": text}
    if reply_to:
        data["reply_to_message_id"] = reply_to
    try:
        requests.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage", data=data)
    except:
        pass

# === AI DECISION ===

def gpt_check_trade(data):
    try:
        payload = {
            "model": "llama3-70b-8192",
            "messages": [
                {"role": "system", "content": "Will this futures/perpetual trade win? Answer YES or NO with confidence like 'YES - 95%'"},
                {"role": "user", "content": json.dumps(data)}
            ]
        }
        r = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=HEADERS, json=payload)
        resp = r.json()["choices"][0]["message"]["content"]
        res, score = resp.split("-")
        return (res.strip().upper() == "YES", float(score.strip().strip("%")))
    except:
        return (False, 0.0)

# === OKX FUTURES PAIRS ===

def fetch_okx_futures():
    url = "https://www.okx.com/api/v5/public/instruments?instType=SWAP"
    res = requests.get(url).json()
    return set(i["instId"].split("-")[0] for i in res.get("data", []))

# === COINGECKO SMART SIGNAL ===

def fetch_top_gecko():
    url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=volume_desc&per_page=100"
    res = requests.get(url).json()
    return [{"pair": coin["symbol"].upper() + "USDT", "price": coin["current_price"]} for coin in res]

# === DEX/WEB SCRAPING SOURCES ===

def fetch_dexscreener_trending():
    res = requests.get("https://api.dexscreener.com/latest/dex/pairs").json()
    tokens = []
    for p in res.get("pairs", [])[:10]:
        symbol = p["baseToken"]["symbol"]
        price = float(p["priceUsd"])
        tokens.append({
            "token": symbol.upper(),
            "entry": str(price),
            "target": str(price * 3),
            "stop": str(price * 0.5)
        })
    return tokens

def fetch_cmc_trending():
    url = "https://coinmarketcap.com/trending-cryptocurrencies/"
    soup = BeautifulSoup(requests.get(url, headers={"User-Agent": "Mozilla"}).text, "lxml")
    tokens = []
    for row in soup.select("table tbody tr")[:10]:
        tag = row.select_one("p.coin-item-symbol")
        if tag:
            symbol = tag.text.strip().upper()
            tokens.append({"token": symbol, "entry": "0.00001", "target": "0.00003", "stop": "0.000005"})
    return tokens

def fetch_coinsniper():
    url = "https://www.coinsniper.net/"
    soup = BeautifulSoup(requests.get(url, headers={"User-Agent": "Mozilla"}).text, "lxml")
    tokens = []
    for tag in soup.select(".token-name")[:10]:
        symbol = tag.text.strip().split()[0].upper()
        tokens.append({"token": symbol, "entry": "0.00001", "target": "0.00003", "stop": "0.000005"})
    return tokens

# === GPT CHAT LISTENER ===

def ask_gpt(user_input):
    try:
        payload = {
            "model": "llama3-70b-8192",
            "messages": [
                {"role": "system", "content": "You are AlphaPulseX AI, a pro crypto trader."},
                {"role": "user", "content": user_input}
            ]
        }
        r = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=HEADERS, json=payload)
        return r.json()["choices"][0]["message"]["content"]
    except:
        return "⚠️ GPT error."

def chat_listener():
    offset = None
    while True:
        try:
            qs = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates", params={"timeout": 60, "offset": offset}).json()["result"]
            for u in qs:
                offset = u["update_id"] + 1
                msg = u.get("message", {})
                if msg.get("chat", {}).get("id") == int(CHAT_ID) and "text" in msg:
                    resp = ask_gpt(msg["text"])
                    send_telegram(resp, reply_to=msg["message_id"])
        except:
            pass
        time.sleep(2)

# === TRADING LOGIC ===

def save_trade(tr):
    with open("trades.json", "a") as f:
        f.write(json.dumps(tr) + "\n")

def check_results():
    try:
        lines = open("trades.json").read().splitlines()
    except:
        return
    out = []
    for l in lines:
        t = json.loads(l)
        if t["status"] == "pending" and datetime.utcnow() - datetime.fromisoformat(t["time"]) > timedelta(hours=1):
            send_telegram(f"✅ Result: {t.get('token') or t.get('pair')} WIN ({t['confidence']}%)")
            t["status"] = "win"
        out.append(t)
    with open("trades.json", "w") as f:
        for t in out:
            f.write(json.dumps(t) + "\n")

def post_summary():
    try:
        lines = open("trades.json").read().splitlines()
        wins = sum(1 for l in lines if json.loads(l)["status"] == "win")
        total = len(lines)
        if total:
            send_telegram(f"📊 Daily Summary\nTotal Trades: {total}\nWins: {wins}\nWin Rate: {round((wins/total)*100, 1)}%")
        else:
            send_telegram("📊 No trades today.")
    except:
        pass

def run_bot():
    threading.Thread(target=chat_listener, daemon=True).start()
    print("🚀 AlphaPulseX AI Bot Running...")
    okx_tokens = fetch_okx_futures()
    last_day = None
    smart_timer = 0
    degen_timer = 0

    while True:
        now = time.time()
        if now - smart_timer >= 900:
            for coin in fetch_top_gecko():
                if coin["pair"].replace("USDT", "") not in okx_tokens:
                    continue
                ok, c = gpt_check_trade(coin)
                if ok and AI_CONFIDENCE_THRESHOLD <= c <= 99.9:
                    send_telegram(f"📈 Smart Signal [{datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}]\nPair: {coin['pair']}\nPrice: {coin['price']}\nLeverage: 10x\nConfidence: {c:.1f}%")
                    save_trade({"type": "smart", **coin, "confidence": c, "status": "pending", "time": datetime.utcnow().isoformat()})
            smart_timer = now

        if now - degen_timer >= 3600:
            sources = fetch_dexscreener_trending() + fetch_cmc_trending() + fetch_coinsniper()
            for d in sources:
                if d["token"] not in okx_tokens:
                    continue
                ok, c = gpt_check_trade(d)
                if ok and AI_CONFIDENCE_THRESHOLD <= c <= 99.9:
                    d["leverage"] = min(max(10, int(c)), 100)
                    send_telegram(f"🔥 Degen Call [{datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}]\nToken: {d['token']}\nEntry: {d['entry']}\nTarget: {d['target']}\nStop: {d['stop']}\nLeverage: {d['leverage']}x\nConfidence: {c:.1f}%")
                    save_trade({"type": "degen", **d, "confidence": c, "status": "pending", "time": datetime.utcnow().isoformat()})
            degen_timer = now

        if datetime.utcnow().strftime("%H:%M") == "23:59" and last_day != datetime.utcnow().date():
            post_summary()
            last_day = datetime.utcnow().date()

        check_results()
        time.sleep(5)

if __name__ == "__main__":
    run_bot()
